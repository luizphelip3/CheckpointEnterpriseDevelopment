package br.com.fiap.entity;

import javax.persistence.*;

@Entity
@Table(name="TB_SINAL")
@SequenceGenerator(name="sinal", sequenceName="SQ_TB_SINAL", allocationSize=1)

public class Sinal {
	@Id
	@Column(name="cd_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="sinal")
	private Integer codigo;
	
	@Column(name="tx_texto")
	private String texto;
	
	@Column(name="tp_tempo_reconhecimento")
	private Integer tempoReconhecimento;

	public Sinal(Integer codigo, String texto, Integer tempoReconhecimento) {
		super();
		this.codigo = codigo;
		this.texto = texto;
		this.tempoReconhecimento = tempoReconhecimento;
	}

	public Sinal(String texto, Integer tempoReconhecimento) {
		super();
		this.texto = texto;
		this.tempoReconhecimento = tempoReconhecimento;
	}

	public Sinal() {
		super();
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Integer getTempoReconhecimento() {
		return tempoReconhecimento;
	}

	public void setTempoReconhecimento(Integer tempoReconhecimento) {
		this.tempoReconhecimento = tempoReconhecimento;
	}

	@Override
	public String toString() {
		return "Sinal [codigo=" + codigo + ", texto=" + texto + ", tempoReconhecimento=" + tempoReconhecimento + "]";
	}
	
	
	
	
	
}
