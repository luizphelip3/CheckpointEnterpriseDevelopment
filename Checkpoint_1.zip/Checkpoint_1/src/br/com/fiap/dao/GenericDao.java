package br.com.fiap.dao;

import javax.persistence.EntityNotFoundException;

import br.com.fiap.exception.CommitException;

public interface GenericDao<E, K> {
	    void insert(E entidade);

	    E findById(K id) throws EntityNotFoundException;

	    void update(E entidade);

	    void delete(K id) throws EntityNotFoundException;

	    void commit() throws CommitException;
	}