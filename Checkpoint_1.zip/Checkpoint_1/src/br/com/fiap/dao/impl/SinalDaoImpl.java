package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.SinalDao;
import br.com.fiap.entity.Sinal;


public class SinalDaoImpl extends GenericDaoImpl<Sinal, Integer> implements SinalDao {
	public SinalDaoImpl(EntityManager em){
		super(em);
	}
	

}