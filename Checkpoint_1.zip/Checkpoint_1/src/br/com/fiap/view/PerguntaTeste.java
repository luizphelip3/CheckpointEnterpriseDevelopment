package br.com.fiap.view;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import br.com.fiap.dao.PerguntaDao;
import br.com.fiap.dao.impl.PerguntaDaoImpl;
import br.com.fiap.entity.Pergunta;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class PerguntaTeste {
	public static void main(String[] args) {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		PerguntaDao dao = new PerguntaDaoImpl(em);
        // public Atendimento(Calendar data, Integer duracao, Integer assunto)
        Pergunta pergunta = new Pergunta("Voc� consegue me ajudar com a transfer�ncia?",120);
        try{
            dao.insert(pergunta);
            dao.commit();
            System.out.println("Pergunta feita com sucesso");
        }catch(CommitException e){
            System.out.println(e.getMessage());
        }

        try{
            pergunta = dao.findById(1);
            System.out.println(pergunta);
        }catch(EntityNotFoundException e){
            System.out.println(e.getMessage());
        }

        em.close();
        EntityManagerFactorySingleton.getInstance().close();
		
	}
	
}
